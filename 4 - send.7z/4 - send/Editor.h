//***************************************************************************************
// Simple Direct3D demo application class.  
// Make sure you link: d3d11.lib D3DCompiler.lib
//***************************************************************************************

#ifndef POSTPROCESSAPP_H
#define POSTPROCESSAPP_H

#if defined(DEBUG) || defined(_DEBUG)
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#endif

#include <d3d11.h>
#include <dxgi.h>

#include <string>

#include "Camera.h"
#include "GameTimer.h"

#include "Scene.h"
//#include "SceneHierarchy.h"
//#include "lua\Game.h"

//#include "3DToolAddCube.h"
//#include "3DToolAddPlane.h"

//#include "Selection3D.h"

//#include "UVUnwrapperWindow.h"


//#include "3DToolAdd2DElement.h"

#include "SpriteBatch.h"
#include "SpriteRenderer.h"

#include "GUI\Button.h"
#include "GUI\TextField.h"
#include "GUI\GUI.h"


#include "PostProcess/PostProcessor.h"


#include "FBXFileLoader.h"
#include "Physics\BulletPhysicEngine.h"
#include "Editor\Physics\EditorPhysics.h"
#include "Actors\Character.h"
#include "renderers\SkinnedModelRenderer.h"

#include "Integrator/GlobalIllumAlgorithm.h"



#include "ManagedRuntime/ManagedRuntimeProxy.h" //in order to init and update the .Net support



#pragma comment (lib, "gdiplus.lib")


class MarchingCubesMesh;
class BallScalarField;
class Blur;

class PostProcessApp
{
public:
	PostProcessApp(HINSTANCE hInstance);
	virtual ~PostProcessApp();

	HINSTANCE AppInst()const;
	HWND      MainWnd()const;
	float     AspectRatio()const;

	int Run();

	virtual bool Init();
	virtual void OnResize();
	virtual void UpdateScene(float dt);
	virtual void DrawScene();

	virtual LRESULT MsgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

	// Convenience overrides for handling mouse input.
	virtual void OnMouseDown(WPARAM btnState, int x, int y);
	virtual void OnMouseUp(WPARAM btnState, int x, int y);
	virtual void OnMouseMove(WPARAM btnState, int x, int y);

	//mes rajouts pr le clic droit
	//virtual void OnMouseRDown(WPARAM btnState, int x, int y);
	//virtual void OnMouseRUp(WPARAM btnState, int x, int y);


	//fixed update will be usefull to do clock synchronized updates for some elements like game entities
	virtual void fixedUpdate();

protected:
	bool InitMainWindow();
	bool InitDirect3D();

	void CalculateFrameStats();
	float RandFloat(float a);

protected:

	HINSTANCE mhAppInst;
	HWND      mhMainWnd;
	bool      mAppPaused;
	bool      mMinimized;
	bool      mMaximized;
	bool      mResizing;
	UINT      m4xMsaaQuality;

	GameTimer mTimer;

	ID3D11Device* md3dDevice;
	ID3D11DeviceContext* md3dImmediateContext;
	IDXGISwapChain* mSwapChain;
	ID3D11Texture2D* mDepthStencilBuffer;
	ID3D11RenderTargetView* mRenderTargetView;
	ID3D11DepthStencilView* mDepthStencilView;
	D3D11_VIEWPORT mScreenViewport;

	// Derived class should set these in derived constructor to customize starting values.
	std::wstring mMainWndCaption;
	D3D_DRIVER_TYPE md3dDriverType;
	int mClientWidth;
	int mClientHeight;
	bool mEnable4xMsaa;

	// Mouse position
	POINT mLastMousePos;
	Camera* mCam;// = NULL;

	Scene* scene;// = NULL;
//	SceneHierarchy* scene_hierarchy;
//	GameCS* m_pGame;

	Camera* camera_materials;

	MeshRenderer mMeshRenderer;

	FBXFileLoader* fbxFile;// = NULL;
	//BulletPhysicEngine* physicEngine;

	Character* character;// = NULL;
	//Selection3D* selection;

	GlobalIllumAlgorithm* m_pGlobalIllumAlgorithm;

	std::vector<MeshRenderer*> renderersToDelete;


	ManagedRuntimeProxy* proxyFuntime; //proxy is an abusive name for this case
	bool oncopyCsharpData;
};



#endif // POSTPROCESSAPP_H
