
#ifndef ANIMATOR_H
#define ANIMATOR_H

#pragma once

#include "..\Skinning\SimpleSkeleton.h"
#include "..\Skinning\Skeleton.h"
#include <Windows.h>


struct Transition
{
	std::string animation_emitter;
	std::string animation_target;
	UINT numConditions;

	std::map<std::string,bool> boolconditions;
	std::map<std::string,int>  intconditions;
	std::map<std::string,float> floatconditiions;
};


//le pb c ke les animations sont aussi contenu dans simpleSkeleton
class Animator
{
private:
	std::vector<SimpleAnimation> animations;
	std::vector<std::string> animation_names;
	UINT currendanimationIndex;

	//here there are global registered conditions. Their values will help us to do transitions according to transitions inside properties
	//toutes les differentes conditions ne peuvent avoir un nom en commun. Ils doivent tous porter un nom different
	std::map<std::string,bool> boolconditions;
	std::map<std::string,int>  intconditions;
	std::map<std::string,float> floatconditiions;

	//std::map<std::string, std::vector<std::string>> list_animation_conditions;

	std::map<std::string, std::vector<std::vector<Transition>>> animations_transitions; //pr une anim on a plusieurs liste de transition selon chaque animation a transiter
	//std::vector<Transition> transitions; //we can use this but in order to accelerate the data accessing process we prefer the data structure below

public:

	void addAnimation(std::string name, SimpleAnimation animation);
	void setTransition(std::string anim_emitter, std::string anim_receiver);
	void addGlobalCondition(std::string name, int type);	//0: bool 1:int 2:float  3:string

	void bindConditionToTransition(std::string anim_emitter, std::string anim_receiver, std::string condition_name, bool value);
	void bindConditionToTransition(std::string anim_emitter, std::string anim_receiver, std::string condition_name, int value);
	void bindConditionToTransition(std::string anim_emitter, std::string anim_receiver, std::string condition_name, float value);
	void bindConditionToTransition(std::string anim_emitter, std::string anim_receiver, std::string condition_name, std::string value);

	//methods like unity
	void setBool(std::string condtion_name, bool value);
	void setInteger(std::string condition_name, int value);
	void setFloat(std::string condition_name, float value);
	void setString(std::string condition_name,std::string value);

	//I don t know how to use settrigger with unity I didn t understand
	// setTrigger(Fire);

	void update(double deltatime);

};


#endif

public void update( double deltatime )
{
		bool ok = false;
		List<> list = currentAnimator.getConditionsList();
		for( unsigned int i=0; i< list.size();i++)
		{
				if( list[i].isBoolean() )
				{
					if( list[i].getBoolean() == true )
						ok=true;
				}
				if( list[i].isInteger() )
				{
					
				}
				if( list[i].isFloat() )
				{
					
				}	
				
		}
		
		if( ok )
		{
			
		}
}

