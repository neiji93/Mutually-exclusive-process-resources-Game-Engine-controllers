#include "Editor.h"
#include <WindowsX.h>
#include <sstream>
#include <cassert>

#include "Utility.h"

#include <DirectXColors.h>
#include <DirectXMath.h>

#include "MarchingCubesMesh.h"
#include "BallScalarField.h"

#include "Draw3DLines.hpp"

#include "GUI\Functions.h"

//#include "Loaders/binary/DXBinaryFile.h"
//#include "Loaders/binary/DXBinaryModel.h"
#include "Lights/LightIBL.h"

#include "Scripting/MessageHandler.h"

//#include "POST/Blur.h"

using namespace DirectX;

namespace
{
    // This is just used to forward Windows messages from a global window
    // procedure to our member function window procedure because we cannot
    // assign a member function to WNDCLASS::lpfnWndProc.
    PostProcessApp* gd3dApp = 0;
}



DirectX::XMMATRIX getCurrentCameraView()
{
    return DirectX::XMMatrixLookAtLH(XMVectorSet(0, -5, 0, 1), XMVectorSet(0, 0, 0, 1), XMVectorSet(0, 1, 0, 0));
}

DirectX::XMMATRIX getCurrentCameraProjection()
{

    float mFovY = 0.25f * XM_PI;
    float mAspect = 1;
    float mNearZ = 1;
    float mFarZ = 500;

    DirectX::XMMATRIX P = DirectX::XMMatrixPerspectiveFovLH(mFovY, mAspect, mNearZ, mFarZ);
    return P;
}


#include <shlobj_core.h>


LRESULT CALLBACK
MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    // Forward hwnd on because we can get messages (e.g., WM_CREATE)
    // before CreateWindow returns, and thus before mhMainWnd is valid.
    return gd3dApp->MsgProc(hwnd, msg, wParam, lParam);
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE prevInstance,
    PSTR cmdLine, int showCmd)
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

    AllocConsole();
    freopen("CONOUT$", "w", stdout);

    PostProcessApp theApp(hInstance);

    if (!theApp.Init())
        return 0;

    return theApp.Run();
}


PostProcessApp::PostProcessApp(HINSTANCE hInstance)
    : mhAppInst(hInstance),
    mMainWndCaption(L"MarchingCubes Demo App"),
    md3dDriverType(D3D_DRIVER_TYPE_HARDWARE),
    mClientWidth(1280),
    mClientHeight(760),
    mEnable4xMsaa(false),
    mhMainWnd(0),
    mAppPaused(false),
    mMinimized(false),
    mMaximized(false),
    mResizing(false),
    m4xMsaaQuality(0),

    md3dDevice(0),
    md3dImmediateContext(0),
    mSwapChain(0),
    mDepthStencilBuffer(0),
    mRenderTargetView(0),
    mDepthStencilView(0)
{
    ZeroMemory(&mScreenViewport, sizeof(D3D11_VIEWPORT));

    // Get a pointer to the application object so we can forward 
    // Windows messages to the object's window procedure through
    // the global window procedure.
    gd3dApp = this;

    mLastMousePos.x = 0;
    mLastMousePos.y = 0;

    mCam = new Camera();
    mCam->SetLens(0.5f * XM_PI, 1.0f, 1.0f, 500.0f);
    mCam->SetPosition(50.0f, 80.0f, 200.0f);
}

PostProcessApp::~PostProcessApp()
{
    LightIBL::Uninitialize();
    for (auto* renderer : renderersToDelete)
    {
        delete renderer;
    }
    EditorPhysicEngine::destroy();
    BulletPhysicEngine::destroy();

    if (mRenderTargetView)
    {
        mRenderTargetView->Release();
        mRenderTargetView = NULL;
    }
    if (mDepthStencilView)
    {
        mDepthStencilView->Release();
        mDepthStencilView = NULL;
    }
    if (mSwapChain)
    {
        mSwapChain->Release();
        mSwapChain = NULL;
    }
    if (mDepthStencilBuffer)
    {
        mDepthStencilBuffer->Release();
        mDepthStencilBuffer = NULL;
    }

    // Restore all default settings.
    if (md3dImmediateContext)
        md3dImmediateContext->ClearState();

    if (md3dImmediateContext)
    {
        md3dImmediateContext->Release();
        md3dImmediateContext = NULL;
    }

#if defined(DEBUG) || defined(_DEBUG)
    ID3D11Debug* d3dDebug;
    md3dDevice->QueryInterface(__uuidof(ID3D11Debug), reinterpret_cast<void**>(&d3dDebug));
    if (d3dDebug != nullptr)
    {
        d3dDebug->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
        d3dDebug->Release();
    }
#endif

    if (md3dDevice)
    {
        md3dDevice->Release();
        md3dDevice = NULL;
    }
    if (m_pGlobalIllumAlgorithm)
    {
        delete m_pGlobalIllumAlgorithm;
    }
    //if (selection)
    //{
      //  delete selection;
    //}

    if (scene)
    {
        delete scene;
    }
    if (mCam)
    {
        delete mCam;
    }
}

HINSTANCE PostProcessApp::AppInst()const
{
    return mhAppInst;
}

HWND PostProcessApp::MainWnd()const
{
    return mhMainWnd;
}

float PostProcessApp::AspectRatio()const
{
    return static_cast<float>(mClientWidth) / mClientHeight;
}

int PostProcessApp::Run()
{
    MSG msg = { 0 };

    mTimer.Reset();

    while (msg.message != WM_QUIT)
    {
        // If there are Window messages then process them.
        if (PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        // Otherwise, do animation/game stuff.
        else
        {
            mTimer.Tick();

            if (!mAppPaused)
            {
                //do fixed updates
                fixedUpdate();
                //m_pGame->update();

                CalculateFrameStats();
                // UpdateScene(mTimer.DeltaTime());


                m_pScriptingEngine->updateScene();

         

               // std::string[] files = MessageHandler::getInstance()->readInterProcessMessage("file.bin");
                if (this->onCopyCsharpData == true)
                {



                   /* for (UINT i = 0; i < files.size(); i++)
                    {
                    */
                        bool resolvedPlayer = false;
                        for (UINT j = 0; j < MessageHandler::getInstance()->getCommandsAtIndex(i).size(); j++)
                        {
							//try to patch for each sent blocks sizes
							//although it must be possible to have no patch
							//to do
							PathcesContainer::getInstance()->executeAllPatches(
								MessageHandler::getInstance()
							);
						
                            resolved = true;
                            if (resolved) //pta )
                            {
                                break;

                            }
                        }

                        if (resolved)
                        {
                            PlayerTest* pt = new PlayerTest();	//emit signal/label in order to execute safe and resolved commabds !
                            //bool found = UntrustedSecurityChecker.checkSecurityFor(pt); //objPlayerTest);

                            //en dessous, declaration des variables qui vont apparaitre dans le contrat
                            //des methodes updates que lon va executer grace a crax
                            int x;
                            int y;
                            int z;

                            if (pt); //pta)
                            {
                                //bool found = TokenResolver.resolve(pta);
                                //if( found )
                                //{
                                    //TokenResolver.transferToCurrentApp();
                                NativeCommandsExecutor::getInstance()->executeIndex(i);
                                pt->x = w;
                                pt->y = y;
                                pt->z = z;
                                //}
                            }

                        }

                    }
                    

                   
            else
            {
                Sleep(100);
            }
        }
    }

    return (int)msg.wParam;
}

bool PostProcessApp::Init()
{
    if (!InitMainWindow())
        return false;

    if (!InitDirect3D())
        return false;

    //ID3D11Buffer* vsb;
    HRESULT hr = S_OK;

    BulletPhysicEngine::create();
    EditorPhysicEngine::create();

    //	mBlur = new Blur(md3dDevice);
    scene = new Scene(g_pd3dDevice, mCam);
    //scene.load("..\\ressources\\scenes\\SceneElements\\scene1.xml");
    //Scene_Hierarchy = new SceneHierarchy("..\\ressources\\scenes\\hieararchies\\hierarchyScene1.xml");
    //m_pGame = new Game(scene, scene_hierarchy); //or (string,string) constructor

/*
    Loaders::binary::DXBinaryFile modelLoader(g_pd3dDevice, g_pImmediateContext);
    modelLoader.SetTextureSearchPath("..\\ressources\\dxl\\textures");
    modelLoader.OpenFile("..\\ressources\\dxl\\test.dxl");

    modelLoader.ProcessDXModels([this](Loaders::binary::DXBinaryModel* binModel)
        {
            std::shared_ptr<Model> model = binModel->CreateModelAndMaterials(g_pd3dDevice);
            MeshRenderer* modelRenderer = new MeshRenderer(g_pd3dDevice, model);
            scene->AddModel(model.get(), modelRenderer)->SetWorldTransform(binModel->GetGlobalTranslation());
            renderersToDelete.push_back(modelRenderer);
        });

    //Tool3DAddCube* _addcube = new Tool3DAddCube( scene );
    //_addcube->applyTool();

    //this->fbxFile = new FBXFileLoader(g_pd3dDevice, g_pImmediateContext, "..\\ressources\\scenes\\item_bunker_huge.fbx");
    //this->fbxFile = new FBXFileLoader(g_pd3dDevice, g_pImmediateContext, "..\\ressources\\scenes\\cube.fbx");
    //this->fbxFile = new FBXFileLoader(g_pd3dDevice, g_pImmediateContext, "..\\ressources\\models\\Player_us_soldier\\us_soldier_idle-crouch with handgun.FBX");
    this->fbxFile = new FBXFileLoader(g_pd3dDevice, g_pImmediateContext, "..\\ressources\\models\\Player_us_soldier\\us_soldier_run simple with handgun.FBX");
    //this->fbxFile = new FBXFileLoader(g_pd3dDevice, g_pImmediateContext, "..\\ressources\\models\\Player_us_soldier\\us_soldier_fire shotgun.FBX");
    scene = new Scene(g_pd3dDevice,mCam);
    Model* m = fbxFile->getModel();

    this->character = new Character(m);

    this->fbxFile->LoadTestAnimation(&this->character->skeleton);
    delete fbxFile;

    fbxFile = new FBXFileLoader(g_pd3dDevice, g_pImmediateContext, "..\\ressources\\models\\Player_us_soldier\\us_soldier_run simple with handgun.FBX");
    fbxFile->AddAnimationToSkeleton(character->skeleton);

    std::shared_ptr<MeshMaterial> material = std::make_shared<MaterialBasic>("Skinned", L"..\\ressources\\shaders\\skinnedmodel.fx", "VS", "PS");
    if (material->Initialize(g_pd3dDevice) == 0)
    {
        m->SetMaterial(g_pd3dDevice, 0, material);

        std::shared_ptr<Model> modelPtr;
        modelPtr.reset(m);
        SkinnedModelRenderer* smrenderer = new SkinnedModelRenderer(g_pd3dDevice, modelPtr);
        SceneElement* characterElement = scene->AddModel(m, smrenderer);
        characterElement->setParameters((void*)this->character);
        characterElement->SetWorldTransform(DirectX::XMMatrixTranslation(-120, 0, 0));
    }
    else
    {
        MessageBox(NULL, L"Could not initialize material", L"Error", MB_OK);
    }
    */
    scene = new Scene(g_pd3dDevice, mCam);
    //this->fbxFile = new FBXFileLoader(g_pd3dDevice, g_pImmediateContext, "..\\ressources\\models\\Player_us_soldier\\us_soldier_idle-crouch with handgun.FBX");

    scene->load("..\\ressources\\scenes\\scene1.xml");

    std::shared_ptr<Light> pointLight = std::make_shared<Light>();
    pointLight->type = Light::POINT;
    pointLight->position.x = -150.0f;
    pointLight->position.y = 50.0f;
    pointLight->position.z = 130.0f;
    pointLight->distance = 800.0f;
    pointLight->direction.x = pointLight->direction.y = pointLight->direction.z = 0;
    pointLight->color.x = 0.2f;
    pointLight->color.y = 0.7f;
    pointLight->color.z = 0.7f;
    pointLight->intensity = 2000;
    scene->AddLight(pointLight);

    pointLight = std::make_shared<Light>();
    pointLight->type = Light::POINT;
    pointLight->position.x = 150.0f;
    pointLight->position.y = 50.0f;
    pointLight->position.z = 100.0f;
    pointLight->distance = 800.0f;
    pointLight->direction.x = pointLight->direction.y = pointLight->direction.z = 0;
    pointLight->color.x = 1.0f;
    pointLight->color.y = 0.7f;
    pointLight->color.z = 0.4f;
    pointLight->intensity = 10000;
    scene->AddLight(pointLight);

    pointLight = std::make_shared<Light>();
    pointLight->type = Light::POINT;
    pointLight->position.x = 100.0f;
    pointLight->position.y = 50.0f;
    pointLight->position.z = -100.0f;
    pointLight->distance = 800.0f;
    pointLight->direction.x = pointLight->direction.y = pointLight->direction.z = 0;
    pointLight->color.x = 0.6f;
    pointLight->color.y = 0.9f;
    pointLight->color.z = 0.2f;
    pointLight->intensity = 10000;
    scene->AddLight(pointLight);

    std::shared_ptr<LightIBL> newIBLLight = std::make_shared<LightIBL>(LightIBL(g_pd3dDevice, L"..\\ressources\\textures\\cubes\\Showroom256.dds"));
    scene->AddLight(newIBLLight);

    //selection = new Selection3D(mCam,mScreenViewport);



    m_pGlobalIllumAlgorithm = new GlobalIllumAlgorithm();

    return true;
}

void PostProcessApp::OnResize()
{
    assert(md3dImmediateContext);
    assert(md3dDevice);
    assert(mSwapChain);

    // Release the old views, as they hold references to the buffers we
    // will be destroying.  Also release the old depth/stencil buffer.

    if (mRenderTargetView)
    {
        mRenderTargetView->Release();
        mRenderTargetView = NULL;
    }
    if (mDepthStencilView)
    {
        mDepthStencilView->Release();
        mDepthStencilView = NULL;
    }
    if (mDepthStencilBuffer)
    {
        mDepthStencilBuffer->Release();
        mDepthStencilBuffer = NULL;
    }

    // Resize the swap chain and recreate the render target view.

    HRESULT hr = mSwapChain->ResizeBuffers(1, mClientWidth, mClientHeight, DXGI_FORMAT_R8G8B8A8_UNORM, 0);
#if defined(DEBUG) | defined(_DEBUG)
    if (FAILED(hr))
    {
        wchar_t msgbuf[512];
        swprintf_s(msgbuf, L"%s (%d) HR=%lX %s\n", WFILE, (DWORD)__LINE__, hr, L"mSwapChain->ResizeBuffers(1, mClientWidth, mClientHeight, DXGI_FORMAT_R8G8B8A8_UNORM, 0)");
        OutputDebugString(msgbuf);
    }
#endif

    ID3D11Texture2D* backBuffer;
    hr = mSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&backBuffer));
    D3D11_RENDER_TARGET_VIEW_DESC desc;
    desc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
    desc.Texture2D.MipSlice = 0;
    hr = md3dDevice->CreateRenderTargetView(backBuffer, &desc, &mRenderTargetView);
    if (backBuffer)
    {
        backBuffer->Release();
        backBuffer = NULL;
    }

    // Create the depth/stencil buffer and view.

    D3D11_TEXTURE2D_DESC depthStencilDesc;

    depthStencilDesc.Width = mClientWidth;
    depthStencilDesc.Height = mClientHeight;
    depthStencilDesc.MipLevels = 1;
    depthStencilDesc.ArraySize = 1;
    depthStencilDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;

    // Use 4X MSAA? --must match swap chain MSAA values.
    if (mEnable4xMsaa)
    {
        depthStencilDesc.SampleDesc.Count = 4;
        depthStencilDesc.SampleDesc.Quality = m4xMsaaQuality - 1;
    }
    // No MSAA
    else
    {
        depthStencilDesc.SampleDesc.Count = 1;
        depthStencilDesc.SampleDesc.Quality = 0;
    }

    depthStencilDesc.Usage = D3D11_USAGE_DEFAULT;
    depthStencilDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    depthStencilDesc.CPUAccessFlags = 0;
    depthStencilDesc.MiscFlags = 0;

    md3dDevice->CreateTexture2D(&depthStencilDesc, 0, &mDepthStencilBuffer);
    md3dDevice->CreateDepthStencilView(mDepthStencilBuffer, 0, &mDepthStencilView);


    // Bind the render target view and depth/stencil view to the pipeline.

    md3dImmediateContext->OMSetRenderTargets(1, &mRenderTargetView, mDepthStencilView);


    // Set the viewport transform.

    mScreenViewport.TopLeftX = 0;
    mScreenViewport.TopLeftY = 0;
    mScreenViewport.Width = static_cast<float>(mClientWidth);
    mScreenViewport.Height = static_cast<float>(mClientHeight);
    mScreenViewport.MinDepth = 0.0f;
    mScreenViewport.MaxDepth = 1.0f;

    md3dImmediateContext->RSSetViewports(1, &mScreenViewport);

    // Take into account aspect ratio of the viewport for camera lens.
    float aspect = mScreenViewport.Width / mScreenViewport.Height;
    mCam->SetLens(0.5f * XM_PI, aspect, 0.1f, 400.0f);

}

LRESULT PostProcessApp::MsgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    oncopyCsharpData = false;
    
    switch (msg)
    {

    //2023
    //see: https://cpp.hotexamples.com/fr/examples/-/-/OnCopyData/cpp-oncopydata-function-examples.html
    case WM_COPYDATA:
        MesssageHandler::getInstance()->onReceiveData(hwnd, (HWND)wParam, (PCOPYDATASTRUCT)lParam);
        oncopyCsharpData = true;
        return;
        // WM_ACTIVATE is sent when the window is activated or deactivated.  
        // We pause the game when the window is deactivated and unpause it 
        // when it becomes active.  
    case WM_ACTIVATE:
        if (LOWORD(wParam) == WA_INACTIVE)
        {
            mAppPaused = true;
            mTimer.Stop();
        }
        else
        {
            mAppPaused = false;
            mTimer.Start();
        }
        return 0;

        // WM_SIZE is sent when the user resizes the window.  
    case WM_SIZE:
        // Save the new client area dimensions.
        mClientWidth = LOWORD(lParam);
        mClientHeight = HIWORD(lParam);
        if (md3dDevice)
        {
            if (wParam == SIZE_MINIMIZED)
            {
                mAppPaused = true;
                mMinimized = true;
                mMaximized = false;
            }
            else if (wParam == SIZE_MAXIMIZED)
            {
                mAppPaused = false;
                mMinimized = false;
                mMaximized = true;
                OnResize();
            }
            else if (wParam == SIZE_RESTORED)
            {

                // Restoring from minimized state?
                if (mMinimized)
                {
                    mAppPaused = false;
                    mMinimized = false;
                    OnResize();
                }

                // Restoring from maximized state?
                else if (mMaximized)
                {
                    mAppPaused = false;
                    mMaximized = false;
                    OnResize();
                }
                else if (mResizing)
                {
                    // If user is dragging the resize bars, we do not resize 
                    // the buffers here because as the user continuously 
                    // drags the resize bars, a stream of WM_SIZE messages are
                    // sent to the window, and it would be pointless (and slow)
                    // to resize for each WM_SIZE message received from dragging
                    // the resize bars.  So instead, we reset after the user is 
                    // done resizing the window and releases the resize bars, which 
                    // sends a WM_EXITSIZEMOVE message.
                }
                else // API call such as SetWindowPos or mSwapChain->SetFullscreenState.
                {
                    OnResize();
                }
            }
        }
        return 0;

        // WM_EXITSIZEMOVE is sent when the user grabs the resize bars.
    case WM_ENTERSIZEMOVE:
        mAppPaused = true;
        mResizing = true;
        mTimer.Stop();
        return 0;

        // WM_EXITSIZEMOVE is sent when the user releases the resize bars.
        // Here we reset everything based on the new window dimensions.
    case WM_EXITSIZEMOVE:
        mAppPaused = false;
        mResizing = false;
        mTimer.Start();
        OnResize();
        return 0;

        // WM_DESTROY is sent when the window is being destroyed.
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;

        // The WM_MENUCHAR message is sent when a menu is active and the user presses 
        // a key that does not correspond to any mnemonic or accelerator key. 
    case WM_MENUCHAR:
        // Don't beep when we alt-enter.
        return MAKELRESULT(0, MNC_CLOSE);

        // Catch this message so to prevent the window from becoming too small.
    case WM_GETMINMAXINFO:
        ((MINMAXINFO*)lParam)->ptMinTrackSize.x = 200;
        ((MINMAXINFO*)lParam)->ptMinTrackSize.y = 200;
        return 0;

    case WM_LBUTTONDOWN:
    case WM_MBUTTONDOWN:
    case WM_RBUTTONDOWN:
        OnMouseDown(wParam, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        return 0;
    case WM_LBUTTONUP:
    case WM_MBUTTONUP:
    case WM_RBUTTONUP:
        OnMouseUp(wParam, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        return 0;
    case WM_MOUSEMOVE:
        OnMouseMove(wParam, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        return 0;
    }

    return DefWindowProc(hwnd, msg, wParam, lParam);
}


bool PostProcessApp::InitMainWindow()
{
    WNDCLASS wc;
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = mhAppInst;
    wc.hIcon = LoadIcon(0, IDI_APPLICATION);
    wc.hCursor = LoadCursor(0, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(NULL_BRUSH);
    wc.lpszMenuName = 0;
    wc.lpszClassName = L"D3DWndClassName";

    if (!RegisterClass(&wc))
    {
        MessageBox(0, L"RegisterClass Failed.", 0, 0);
        return false;
    }

    // Compute window rectangle dimensions based on requested client area dimensions.
    RECT R = { 0, 0, mClientWidth, mClientHeight };
    AdjustWindowRect(&R, WS_OVERLAPPEDWINDOW, false);
    int width = R.right - R.left;
    int height = R.bottom - R.top;

    mhMainWnd = CreateWindow(L"D3DWndClassName", mMainWndCaption.c_str(),
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, width, height, 0, 0, mhAppInst, 0);
    if (!mhMainWnd)
    {
        MessageBox(0, L"CreateWindow Failed.", 0, 0);
        return false;
    }

    ShowWindow(mhMainWnd, SW_SHOW);
    UpdateWindow(mhMainWnd);

    return true;
}

bool PostProcessApp::InitDirect3D()
{
    // Create the device and device context.

    UINT createDeviceFlags = 0;
#if defined(DEBUG) || defined(_DEBUG)  
    createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

    D3D_FEATURE_LEVEL featureLevel;
    HRESULT hr = D3D11CreateDevice(
        0,                 // default adapter
        md3dDriverType,
        0,                 // no software device
        createDeviceFlags,
        0, 0,              // default feature level array
        D3D11_SDK_VERSION,
        &md3dDevice,
        &featureLevel,
        &md3dImmediateContext);

    if (FAILED(hr))
    {
        hr = D3D11CreateDevice(
            0,                 // default adapter
            D3D_DRIVER_TYPE_REFERENCE,  // Try reference SW driver
            0,                 // no software device
            createDeviceFlags,
            0, 0,              // default feature level array
            D3D11_SDK_VERSION,
            &md3dDevice,
            &featureLevel,
            &md3dImmediateContext);
        if (FAILED(hr))
        {
            MessageBox(0, L"D3D11CreateDevice Failed.", 0, 0);
            return false;
        }
    }

    if (featureLevel != D3D_FEATURE_LEVEL_11_0)
    {
        MessageBox(0, L"Direct3D Feature Level 11 unsupported.", 0, 0);
        return false;
    }

    // Check 4X MSAA quality support for our back buffer format.
    // All Direct3D 11 capable devices support 4X MSAA for all render 
    // target formats, so we only need to check quality support.

    md3dDevice->CheckMultisampleQualityLevels(DXGI_FORMAT_R8G8B8A8_UNORM, 4, &m4xMsaaQuality);
    assert(m4xMsaaQuality > 0);

    // Fill out a DXGI_SWAP_CHAIN_DESC to describe our swap chain.

    DXGI_SWAP_CHAIN_DESC sd;
    sd.BufferDesc.Width = mClientWidth;
    sd.BufferDesc.Height = mClientHeight;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
    sd.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;

    // Use 4X MSAA? 
    if (mEnable4xMsaa)
    {
        sd.SampleDesc.Count = 4;
        sd.SampleDesc.Quality = m4xMsaaQuality - 1;
    }
    // No MSAA
    else
    {
        sd.SampleDesc.Count = 1;
        sd.SampleDesc.Quality = 0;
    }

    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.BufferCount = 1;
    sd.OutputWindow = mhMainWnd;
    sd.Windowed = true;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    sd.Flags = 0;

    // To correctly create the swap chain, we must use the IDXGIFactory that was
    // used to create the device.  If we tried to use a different IDXGIFactory instance
    // (by calling CreateDXGIFactory), we get an error: "IDXGIFactory::CreateSwapChain: 
    // This function is being called with a device from a different IDXGIFactory."

    IDXGIDevice* dxgiDevice = 0;
    md3dDevice->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDevice);

    IDXGIAdapter* dxgiAdapter = 0;
    dxgiDevice->GetParent(__uuidof(IDXGIAdapter), (void**)&dxgiAdapter);

    IDXGIFactory* dxgiFactory = 0;
    dxgiAdapter->GetParent(__uuidof(IDXGIFactory), (void**)&dxgiFactory);

    dxgiFactory->CreateSwapChain(md3dDevice, &sd, &mSwapChain);

    if (dxgiDevice)
    {
        dxgiDevice->Release();
        dxgiDevice = NULL;
    }
    if (dxgiFactory)
    {
        dxgiFactory->Release();
        dxgiFactory = NULL;
    }

    // The remaining steps that need to be carried out for d3d creation
    // also need to be executed every time the window is resized.  So
    // just call the OnResize method here to avoid code duplication.

    OnResize();


    g_pd3dDevice = md3dDevice;
    g_pImmediateContext = md3dImmediateContext;

    InitgUtils2();

    return true;
}

void PostProcessApp::CalculateFrameStats()
{
    // Code computes the average frames per second, and also the 
    // average time it takes to render one frame.  These stats 
    // are appended to the window caption bar.

    static int frameCnt = 0;
    static float timeElapsed = 0.0f;

    frameCnt++;

    // Compute averages over one second period.
    if ((mTimer.TotalTime() - timeElapsed) >= 1.0f)
    {
        float fps = (float)frameCnt; // fps = frameCnt / 1
        float mspf = 1000.0f / fps;

        std::wostringstream outs;
        outs.precision(6);
        outs << mMainWndCaption << L"    "
            << L"FPS: " << fps << L"    "
            << L"Frame Time: " << mspf << L" (ms)";
        SetWindowText(mhMainWnd, outs.str().c_str());

        // Reset for next average.
        frameCnt = 0;
        timeElapsed += 1.0f;
    }
}

void PostProcessApp::OnMouseDown(WPARAM btnState, int x, int y)
{
    mLastMousePos.x = x;
    mLastMousePos.y = y;

    SetCapture(mhMainWnd);
}

void PostProcessApp::OnMouseUp(WPARAM btnState, int x, int y)
{
    ReleaseCapture();
}





void PostProcessApp::OnMouseMove(WPARAM btnState, int x, int y)
{
}

void PostProcessApp::UpdateScene(float dt)
{
    const float walkSpeed = 100.0f;
    if (GetAsyncKeyState('W') & 0x8000)
        this->mCam->Walk(walkSpeed * dt);

    if (GetAsyncKeyState('S') & 0x8000)
        this->mCam->Walk(-walkSpeed * dt);

    if (GetAsyncKeyState('A') & 0x8000)
        this->mCam->Strafe(-walkSpeed * dt);

    if (GetAsyncKeyState('D') & 0x8000)
        this->mCam->Strafe(walkSpeed * dt);

    if (character)
    {
        character->update(dt);
    }
    this->scene->update(dt);

    //rajout decembre 2022 : appelons cette methode apres le update du scriptingEngine 
    //pour mettre a jour les entity
    //playerTest.x
    //playerTestSceneElement.move( playerTest.x, playerTest.y, playerTest.z);
    std::vector<SceneElement*> se = this->scene->getSceneElements();
    se["PlayerTestSceneElements"]->move(playerTest.x, playerTest.y, playerTest.z);


}


float PostProcessApp::RandFloat(float a)
{
    return ((float)rand() / (float)(RAND_MAX)) * a - 0.5f * a;
}


void PostProcessApp::DrawScene()
{
    mCam->UpdateViewMatrix();

    md3dImmediateContext->ClearRenderTargetView(mRenderTargetView, reinterpret_cast<const float*>(&Colors::LightSteelBlue));
    md3dImmediateContext->ClearDepthStencilView(mDepthStencilView, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

    scene->Render();
    //selection->Render(mCam);

    m_pGlobalIllumAlgorithm->integrateDirect(mCam, scene);
    //selection->Render(mCam);

    mSwapChain->Present(0, 0);
}

void PostProcessApp::fixedUpdate()
{
    //the code is like fps calculations
    // Code computes the average frames per second, and also the 
    // average time it takes to render one frame.  These stats 
    // are appended to the window caption bar.

    //static int frameCnt = 0;
    static float timeElapsed = 0.0f;

    //frameCnt++;

    // Compute averages over one second period.
    if ((mTimer.TotalTime() - timeElapsed) >= 1.0f)
    {
        /*//float fps = (float)frameCnt; // fps = frameCnt / 1
        float mspf = 1000.0f / fps;

        std::wostringstream outs;
        outs.precision(6);
        outs << mMainWndCaption << L"    "
            << L"FPS: " << fps << L"    "
            << L"Frame Time: " << mspf << L" (ms)";
        SetWindowText(mhMainWnd, outs.str().c_str());
        */
        //next
        timeElapsed += 1.0f;
    }
}